package de.htwg.se.colorwoodSort.view

import de.htwg.se.colorwoodSort.model.GameState
import de.htwg.se.colorwoodSort.controller.GameController

class TUI(gameState: GameState) {
  private val view = new GameView()
  private val controller = new GameController(gameState, view)

  def start(): Unit = {
    controller.start()
  }
} 