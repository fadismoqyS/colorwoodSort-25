package de.htwg.se.colorwoodSort.model

case class ColorBlock(color: String)