package de.htwg.se.colorwoodSort.util

trait Observer {
  def update(): Unit
}
